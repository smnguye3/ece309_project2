#include "core/message.h"

#include <cassert>
#include <cstdio>
#include <fstream>
#include <memory>
#include <stdexcept>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#define private public
#include "core/conversation.h"
#include "core/sentinel_scanner.h"
#undef private

#include "harness/harness.h"
#include "model/replay_client.h"
#include "model/scripted_client.h"

namespace {

const std::string kSentinel = "<|end_conversation|>";

class VectorInput : public InputSource {
public:
    explicit VectorInput(std::vector<std::string> lines)
        : lines_(std::move(lines)) {}

    std::string read_line() override {
        if (next_ >= lines_.size()) {
            eof_ = true;
            return "";
        }
        return lines_[next_++];
    }

    bool is_eof() const override { return eof_; }

private:
    std::vector<std::string> lines_;
    std::size_t next_ = 0;
    bool eof_ = false;
};

class StringOutput : public OutputSink {
public:
    void write(std::string_view text) override { text_ += text; }
    const std::string& str() const { return text_; }

private:
    std::string text_;
};

std::string temp_path(const std::string& name) {
    return "ece309_p2_" + name;
}

void write_file(const std::string& path, const std::string& text) {
    std::ofstream out(path);
    assert(out.is_open());
    out << text;
}

void test_message_basics() {
    Message def;
    assert(def.role() == Role::System);
    assert(def.content().empty());

    Message user(Role::User, "hello");
    assert(user.role() == Role::User);
    assert(user.content() == "hello");
}

void test_empty_conversation_bounds() {
    Conversation c;
    assert(c.size() == 0);
    assert(c.begin() == c.end());

    bool threw = false;
    try {
        (void)c.at(0);
    } catch (const std::out_of_range&) {
        threw = true;
    }
    assert(threw);
}

void test_system_message_ordering() {
    Conversation c;
    c.append(Message(Role::System, "Be concise."));
    c.append(Message(Role::User, "hello"));
    c.append(Message(Role::Assistant, "hi"));

    assert(c.size() == 3);
    assert(c.at(0).role() == Role::System);
    assert(c.at(0).content() == "Be concise.");
    assert(c.at(1).role() == Role::User);
    assert(c.at(2).role() == Role::Assistant);
}

void test_copy_constructor_deep_copy() {
    Conversation a;
    a.append(Message(Role::User, "one"));
    a.append(Message(Role::Assistant, "two"));

    Conversation b(a);
    assert(b.size() == a.size());
    assert(b.begin() != a.begin());
    assert(b.at(0).content() == "one");
    assert(b.at(1).content() == "two");
}

void test_copy_assignment_deep_copy_and_self_assignment() {
    Conversation a;
    a.append(Message(Role::User, "alpha"));
    a.append(Message(Role::Assistant, "beta"));

    Conversation b;
    b.append(Message(Role::System, "old"));
    b = a;
    assert(b.size() == 2);
    assert(b.begin() != a.begin());
    assert(b.at(0).content() == "alpha");

    const Message* before = b.begin();
    b = b;
    assert(b.begin() == before);
    assert(b.size() == 2);
}

void test_move_constructor_steals_buffer() {
    Conversation source;
    source.append(Message(Role::User, "move me"));
    const Message* original = source.begin();

    Conversation dest(std::move(source));
    assert(dest.begin() == original);
    assert(dest.size() == 1);
    assert(dest.at(0).content() == "move me");
    assert(source.data_ == nullptr);
    assert(source.size_ == 0);
    assert(source.capacity_ == 0);
}

void test_move_assignment_steals_buffer() {
    Conversation source;
    source.append(Message(Role::Assistant, "payload"));
    const Message* original = source.begin();

    Conversation dest;
    dest.append(Message(Role::User, "discard"));
    dest = std::move(source);

    assert(dest.begin() == original);
    assert(dest.size() == 1);
    assert(dest.at(0).content() == "payload");
    assert(source.data_ == nullptr);
    assert(source.size_ == 0);
    assert(source.capacity_ == 0);
}

void test_growth_behavior() {
    Conversation c;
    const std::size_t expected_capacity[] = {1, 2, 4, 4, 8, 8, 8, 8, 16};

    for (int i = 0; i < 9; ++i) {
        c.append(Message(Role::User, std::to_string(i)));
        assert(c.size() == static_cast<std::size_t>(i + 1));
        assert(c.capacity_ == expected_capacity[i]);
        assert(c.at(i).content() == std::to_string(i));
    }

    for (int i = 0; i < 9; ++i) {
        assert(c.at(i).content() == std::to_string(i));
    }
}

void test_range_iteration_oldest_first() {
    Conversation c;
    c.append(Message(Role::User, "A"));
    c.append(Message(Role::Assistant, "B"));
    c.append(Message(Role::User, "C"));

    std::string joined;
    for (const Message& m : c) joined += m.content();
    assert(joined == "ABC");
}

void test_scanner_clean_text() {
    SentinelScanner scanner(kSentinel);
    std::string emitted;
    emitted += scanner.feed("ordinary ").safe_text;
    emitted += scanner.feed("text only").safe_text;
    auto tail = scanner.flush();
    emitted += tail.safe_text;

    assert(!tail.sentinel_found);
    assert(emitted == "ordinary text only");
}

void test_scanner_whole_sentinel() {
    SentinelScanner scanner(kSentinel);
    auto out = scanner.feed("Goodbye." + kSentinel);
    assert(out.sentinel_found);
    assert(out.safe_text == "Goodbye.");
    assert(scanner.pending_.empty());
}

void test_scanner_split_at_every_boundary() {
    const std::string text = "Goodbye." + kSentinel;

    for (std::size_t split = 0; split <= text.size(); ++split) {
        SentinelScanner scanner(kSentinel);
        auto out1 = scanner.feed(text.substr(0, split));
        auto out2 = scanner.feed(text.substr(split));
        assert(out1.sentinel_found || out2.sentinel_found);
        assert(out1.safe_text + out2.safe_text == "Goodbye.");
    }
}

void test_scanner_one_character_at_a_time() {
    SentinelScanner scanner(kSentinel);
    const std::string text = "prefix" + kSentinel + "ignored";
    std::string safe;
    bool found = false;

    for (char ch : text) {
        auto out = scanner.feed(std::string(1, ch));
        safe += out.safe_text;
        if (out.sentinel_found) {
            found = true;
            break;
        }
    }

    assert(found);
    assert(safe == "prefix");
}

void test_scanner_false_alarm_and_flush() {
    SentinelScanner scanner(kSentinel);
    const std::string text = "before<|end_world|>after";
    std::string safe;

    auto first = scanner.feed(text);
    assert(!first.sentinel_found);
    safe += first.safe_text;

    auto last = scanner.flush();
    assert(!last.sentinel_found);
    safe += last.safe_text;
    assert(safe == text);
}

void test_scanner_pending_is_bounded() {
    SentinelScanner scanner(kSentinel);
    const std::string adversarial = "<|end_<|end_<|end_<|end_";
    const std::size_t target_bytes = 4 * 1024 * 1024;
    std::size_t fed = 0;

    while (fed < target_bytes) {
        for (char ch : adversarial) {
            if (fed == target_bytes) break;
            auto out = scanner.feed(std::string(1, ch));
            assert(!out.sentinel_found);
            assert(scanner.pending_.size() <= kSentinel.size() - 1);
            ++fed;
        }
    }

    auto tail = scanner.flush();
    assert(!tail.sentinel_found);
    assert(scanner.pending_.empty());
}

void test_harness_turn_limit() {
    const std::string path = temp_path("turn_limit.script");
    write_file(path,
        "role: assistant\nfirst reply\n---\n"
        "role: assistant\nsecond reply\n");

    auto model = std::make_unique<ScriptedModelClient>(path);
    HarnessConfig cfg;
    cfg.max_turns = 2;
    Harness harness(std::move(model), cfg);
    VectorInput in({"one", "two"});
    StringOutput out;

    StopReason reason = harness.run(in, out);
    assert(reason.kind == StopReason::Kind::TurnLimit);
    assert(harness.conversation().size() == 4);
    std::remove(path.c_str());
}

void test_harness_sentinel_halt_and_hidden_sentinel() {
    const std::string path = temp_path("sentinel.script");
    write_file(path,
        "chunk: 3\n"
        "role: assistant\nGoodbye.<|end_conversation|>SHOULD_NOT_APPEAR\n");

    auto model = std::make_unique<ScriptedModelClient>(path);
    HarnessConfig cfg;
    cfg.max_turns = 5;
    Harness harness(std::move(model), cfg);
    VectorInput in({"bye"});
    StringOutput out;

    StopReason reason = harness.run(in, out);
    assert(reason.kind == StopReason::Kind::Sentinel);
    assert(out.str().find("Goodbye.") != std::string::npos);
    assert(out.str().find(kSentinel) == std::string::npos);
    assert(out.str().find("SHOULD_NOT_APPEAR") == std::string::npos);
    assert(harness.conversation().at(1).content() == "Goodbye." + kSentinel);
    std::remove(path.c_str());
}

void test_harness_user_eof() {
    const std::string path = temp_path("eof.script");
    write_file(path, "role: assistant\nunused\n");

    auto model = std::make_unique<ScriptedModelClient>(path);
    HarnessConfig cfg;
    Harness harness(std::move(model), cfg);
    VectorInput in({});
    StringOutput out;

    StopReason reason = harness.run(in, out);
    assert(reason.kind == StopReason::Kind::UserExit);
    assert(harness.conversation().size() == 0);
    std::remove(path.c_str());
}

void test_system_message_from_script_is_pinned_first() {
    const std::string path = temp_path("system.script");
    write_file(path,
        "role: system\nBe concise.\n---\n"
        "role: assistant\nDone.<|end_conversation|>\n");

    auto concrete = std::make_unique<ScriptedModelClient>(path);
    HarnessConfig cfg;
    cfg.system_message = concrete->system_message();
    Harness harness(std::move(concrete), cfg);
    VectorInput in({"go"});
    StringOutput out;

    StopReason reason = harness.run(in, out);
    assert(reason.kind == StopReason::Kind::Sentinel);
    assert(harness.conversation().at(0).role() == Role::System);
    assert(harness.conversation().at(0).content() == "Be concise.");
    std::remove(path.c_str());
}

void test_transcript_round_trip_replay() {
    const std::string path = temp_path("round_trip.txt");
    write_file(path,
        "role: system\nBe concise.\n---\n"
        "role: user\nhello\n---\n"
        "role: assistant\nHi there.\n---\n"
        "role: user\nbye\n---\n"
        "role: assistant\nGoodbye.<|end_conversation|>\n");

    ReplayModelClient replay(path);
    assert(replay.system_message() == "Be concise.");

    Conversation conv;
    conv.append(Message(Role::System, replay.system_message()));
    conv.append(Message(Role::User, "hello"));
    Message first = replay.generate(conv);
    assert(first.role() == Role::Assistant);
    assert(first.content() == "Hi there.");

    conv.append(first);
    conv.append(Message(Role::User, "bye"));
    Message second = replay.generate(conv);
    assert(second.content() == "Goodbye." + kSentinel);

    std::remove(path.c_str());
}

}  // namespace

int main() {
    test_message_basics();
    test_empty_conversation_bounds();
    test_system_message_ordering();
    test_copy_constructor_deep_copy();
    test_copy_assignment_deep_copy_and_self_assignment();
    test_move_constructor_steals_buffer();
    test_move_assignment_steals_buffer();
    test_growth_behavior();
    test_range_iteration_oldest_first();
    test_scanner_clean_text();
    test_scanner_whole_sentinel();
    test_scanner_split_at_every_boundary();
    test_scanner_one_character_at_a_time();
    test_scanner_false_alarm_and_flush();
    test_scanner_pending_is_bounded();
    test_harness_turn_limit();
    test_harness_sentinel_halt_and_hidden_sentinel();
    test_harness_user_eof();
    test_system_message_from_script_is_pinned_first();
    test_transcript_round_trip_replay();
    return 0;
}
