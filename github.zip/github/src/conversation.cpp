#include "core/conversation.h"

#include <stdexcept>
#include <utility>

Conversation::Conversation() = default;

// Free the dynamically allocated message array.
Conversation::~Conversation() {
    delete[] data_;
}
// Deep-copy the other conversation into a new buffer.
Conversation::Conversation(const Conversation& other)
    : data_(other.capacity_ == 0 ? nullptr : new Message[other.capacity_]),
      size_(other.size_),
      capacity_(other.capacity_) {
    try {
        for (std::size_t i = 0; i < size_; ++i) {
            data_[i] = other.data_[i];
        }
    } catch (...) {
        delete[] data_;
        data_ = nullptr;
        size_ = 0;
        capacity_ = 0;
        throw;
    }
}

Conversation& Conversation::operator=(const Conversation& other) {
    if (this == &other) {
        return *this;
    }

    // Copy first, then swap ownership.  If copying throws, *this is unchanged.
    Conversation copy(other);
    std::swap(data_, copy.data_);
    std::swap(size_, copy.size_);
    std::swap(capacity_, copy.capacity_);
    return *this;
}
// Steal the buffer and leave the source empty.
Conversation::Conversation(Conversation&& other) noexcept
    : data_(other.data_), size_(other.size_), capacity_(other.capacity_) {
    other.data_ = nullptr;
    other.size_ = 0;
    other.capacity_ = 0;
}
// Release current storage, then take ownership of the source buffer.
Conversation& Conversation::operator=(Conversation&& other) noexcept {
    if (this == &other) {
        return *this;
    }

    delete[] data_;

    data_ = other.data_;
    size_ = other.size_;
    capacity_ = other.capacity_;

    other.data_ = nullptr;
    other.size_ = 0;
    other.capacity_ = 0;
    return *this;
}
// Double capacity when the backing array is full.
void Conversation::append(Message m) {
    if (size_ == capacity_) {
        const std::size_t new_capacity = (capacity_ == 0) ? 1 : capacity_ * 2;
        Message* new_data = new Message[new_capacity];
// Move existing messages into the new larger buffer.
        try {
            for (std::size_t i = 0; i < size_; ++i) {
                new_data[i] = std::move_if_noexcept(data_[i]);
            }
            new_data[size_] = std::move(m);
        } catch (...) {
            delete[] new_data;
            throw;
        }

        delete[] data_;
        data_ = new_data;
        capacity_ = new_capacity;
        ++size_;
        return;
    }

    data_[size_] = std::move(m);
    ++size_;
}

std::size_t Conversation::size() const noexcept {
    return size_;
}
// Throw if the requested index is outside the conversation.
const Message& Conversation::at(std::size_t i) const {
    if (i >= size_) {
        throw std::out_of_range("Conversation::at index out of range");
    }
    return data_[i];
}

const Message* Conversation::begin() const noexcept {
    return data_;
}

const Message* Conversation::end() const noexcept {
    return data_ == nullptr ? nullptr : data_ + size_;
}
