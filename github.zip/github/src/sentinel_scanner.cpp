#include "core/sentinel_scanner.h"

#include <stdexcept>
#include <utility>

SentinelScanner::SentinelScanner(std::string sentinel)
    : sentinel_(std::move(sentinel)) {
    if (sentinel_.empty()) {
        throw std::invalid_argument("SentinelScanner sentinel must not be empty");
    }
}

SentinelScanner::Out SentinelScanner::feed(std::string_view chunk) {
    if (found_) {
        return {"", true};
    }
// Combine the previous possible sentinel prefix with the new chunk.
    std::string combined;
    combined.reserve(pending_.size() + chunk.size());
    combined += pending_;
    combined.append(chunk.data(), chunk.size());
// Check whether the complete sentinel has arrived.
    const std::size_t match = combined.find(sentinel_);
    if (match != std::string::npos) {
        found_ = true;
        pending_.clear();
        return {combined.substr(0, match), true};
    }
// Keep at most sentinel length - 1 characters that may form a future match.
    const std::size_t hold = sentinel_.size() - 1;
    if (combined.size() <= hold) {
        pending_ = std::move(combined);
        return {"", false};
    }
// Everything before the held suffix is safe to emit.
    const std::size_t safe_count = combined.size() - hold;
    std::string safe = combined.substr(0, safe_count);
    pending_ = combined.substr(safe_count);
    return {std::move(safe), false};
}
// Release any remaining buffered text when the stream ends.
SentinelScanner::Out SentinelScanner::flush() {
    if (found_) {
        return {"", true};
    }

    std::string safe = std::move(pending_);
    pending_.clear();
    return {std::move(safe), false};
}
